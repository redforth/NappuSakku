@echo off
REM Double-click launcher. Keeps all PowerShell logic in the .ps1 file.
REM Pass-through args: Uninstall-NappuSakku.bat -KeepNotes
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Uninstall-NappuSakku.ps1" %*
pause
