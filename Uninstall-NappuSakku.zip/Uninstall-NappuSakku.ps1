<#
============================================================
 Uninstall-NappuSakku.ps1
 Removes files/folders the NappuSakku SF6 overlay mod creates.

 KEEPS the shared REFramework folders themselves:
   reframework\autorun , reframework\data , reframework\images
 ...and only deletes NappuSakku's own contents inside them.

 USAGE
   Right-click > Run with PowerShell, OR from a shell:
     powershell -ExecutionPolicy Bypass -File .\Uninstall-NappuSakku.ps1

   Optional args:
     -GamePath "D:\...\StreetFighter6"   Point at the SF6 game folder
                                         (auto-detected if omitted).
     -KeepNotes    Preserve your combo/character notes; delete only the
                   read-only reference framedata.json files.
     -Force        Skip the confirmation prompt.

 Pure ASCII, no external modules. Safe to re-run.
============================================================
#>

[CmdletBinding()]
param(
    [string]$GamePath,
    [switch]$KeepNotes,
    [switch]$Force
)

$ErrorActionPreference = 'Stop'

# ----- Locate the reframework root ---------------------------------------
# A game-root folder is only accepted if it looks like a real SF6 install.
# This is what stops the script from matching the 'reframework' folder that
# ships INSIDE the downloaded NappuSakku folder (that copy has no game exe
# or REFramework loader next to it).
$script:SF6_MARKERS = @('StreetFighter6.exe','dinput8.dll')

function Test-SF6Root {
    param([string]$Dir)   # candidate GAME root (the parent of reframework\)
    if (-not $Dir) { return $false }
    foreach ($m in $script:SF6_MARKERS) {
        if (Test-Path -LiteralPath (Join-Path $Dir $m) -PathType Leaf) { return $true }
    }
    return $false
}

# Best-effort Steam auto-discovery (SF6 AppID = 1364780).
function Get-SteamSF6Root {
    $steamPaths = @()
    foreach ($hive in 'HKCU:\SOFTWARE\Valve\Steam','HKLM:\SOFTWARE\WOW6432Node\Valve\Steam','HKLM:\SOFTWARE\Valve\Steam') {
        try {
            $p = (Get-ItemProperty -Path $hive -ErrorAction Stop).SteamPath
            if ($p) { $steamPaths += $p }
        } catch {}
    }
    foreach ($s in ($steamPaths | Where-Object { $_ } | Select-Object -Unique)) {
        $libs = @($s)
        $vdf = Join-Path $s 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $vdf) {
            foreach ($line in (Get-Content -LiteralPath $vdf)) {
                if ($line -match '"path"\s+"(.+?)"') { $libs += ($matches[1] -replace '\\\\','\') }
            }
        }
        foreach ($lib in ($libs | Where-Object { $_ } | Select-Object -Unique)) {
            $cand = Join-Path $lib 'steamapps\common\Street Fighter 6'
            if ((Test-Path -LiteralPath (Join-Path $cand 'reframework\autorun')) -and (Test-SF6Root $cand)) {
                return (Resolve-Path $cand).Path
            }
        }
    }
    return $null
}

function Test-IsReframework {
    param([string]$Root)   # does $Root\reframework\ have autorun+data ?
    $rf = Join-Path $Root 'reframework'
    return ((Test-Path (Join-Path $rf 'autorun')) -and (Test-Path (Join-Path $rf 'data')))
}

function Resolve-ReframeworkRoot {
    param([string]$Hint)

    $here = Split-Path -Parent $MyInvocation.PSCommandPath
    if (-not $here) { $here = (Get-Location).Path }

    # 1) Explicit -GamePath wins. Accept either the game folder or a
    #    reframework folder. Missing SF6 marker only warns (you told us).
    if ($Hint) {
        $root = if ((Split-Path -Leaf $Hint) -ieq 'reframework') { Split-Path -Parent $Hint } else { $Hint }
        if (Test-IsReframework $root) {
            if (-not (Test-SF6Root $root)) {
                Write-Host "WARNING: no StreetFighter6.exe/dinput8.dll in '$root'." -ForegroundColor Yellow
                Write-Host "         Proceeding anyway because you passed -GamePath." -ForegroundColor Yellow
            }
            return (Resolve-Path (Join-Path $root 'reframework')).Path
        }
        Write-Host "WARNING: '$Hint' has no reframework\autorun+data. Ignoring it." -ForegroundColor Yellow
    }

    # 2) Auto-detect near the script, but ONLY accept a real SF6 install.
    foreach ($root in @($here, (Split-Path -Parent $here)) | Where-Object { $_ } | Select-Object -Unique) {
        if ((Test-IsReframework $root) -and (Test-SF6Root $root)) {
            return (Resolve-Path (Join-Path $root 'reframework')).Path
        }
    }

    # 3) Steam auto-discovery.
    $steam = Get-SteamSF6Root
    if ($steam) { return (Join-Path $steam 'reframework') }

    # Nothing valid. If we're sitting in the download copy, say so plainly.
    foreach ($root in @($here, (Split-Path -Parent $here)) | Where-Object { $_ }) {
        if ((Test-IsReframework $root) -and -not (Test-SF6Root $root)) {
            Write-Host "This looks like the downloaded NappuSakku folder, not the game install." -ForegroundColor Yellow
            break
        }
    }
    return $null
}

$rf = Resolve-ReframeworkRoot -Hint $GamePath
if (-not $rf) {
    Write-Host "Could not find your Street Fighter 6 install." -ForegroundColor Red
    Write-Host "Re-run pointing at the game folder (the one with StreetFighter6.exe):" -ForegroundColor Yellow
    Write-Host '  .\Uninstall-NappuSakku.ps1 -GamePath "D:\Steam\steamapps\common\Street Fighter 6"' -ForegroundColor Yellow
    exit 1
}

$autorun = Join-Path $rf 'autorun'
$data    = Join-Path $rf 'data'
$images  = Join-Path $rf 'images'

$gameRoot = Split-Path -Parent $rf
$marker   = ($script:SF6_MARKERS | Where-Object { Test-Path -LiteralPath (Join-Path $gameRoot $_) -PathType Leaf } | Select-Object -First 1)

Write-Host ""
Write-Host "NappuSakku uninstaller" -ForegroundColor Cyan
Write-Host "SF6 install:      $gameRoot"
Write-Host ("verified by:      {0}" -f ($(if ($marker) { $marker } else { '(none - unverified, via -GamePath)' })))
Write-Host "reframework root: $rf"
Write-Host ""

# ----- Build the target lists (only items that actually exist) -----------
$targets = New-Object System.Collections.Generic.List[object]

function Add-Target {
    param([string]$Path, [string]$Kind)   # Kind: File | Dir
    if ($Kind -eq 'Dir') {
        if (Test-Path -LiteralPath $Path -PathType Container) {
            $targets.Add([pscustomobject]@{ Path=$Path; Kind='Dir' })
        }
    } else {
        if (Test-Path -LiteralPath $Path -PathType Leaf) {
            $targets.Add([pscustomobject]@{ Path=$Path; Kind='File' })
        }
    }
}

# autorun\  -> Lua scripts (folder kept)
foreach ($f in 'SF6_Overlay.lua','mr_winrate.lua','sf6_roster_export.lua') {
    Add-Target (Join-Path $autorun $f) 'File'
}

# data\  -> config / roster / stance / debug files (folder kept)
foreach ($f in 'sf6_overlay_config.json','sf6_roster.json','sf6_stances.json','sf6_fd_debug.txt') {
    Add-Target (Join-Path $data $f) 'File'
}
# data\moves\  -> downloaded move images (always removable, not user notes)
Add-Target (Join-Path $data 'moves') 'Dir'

# data\sf6_framedata\  -> per-character folder tree
$fdRoot = Join-Path $data 'sf6_framedata'
if (Test-Path -LiteralPath $fdRoot -PathType Container) {
    if ($KeepNotes) {
        # Delete only the read-only reference framedata.json in each char folder.
        Get-ChildItem -LiteralPath $fdRoot -Recurse -Filter 'framedata.json' -File |
            ForEach-Object { $targets.Add([pscustomobject]@{ Path=$_.FullName; Kind='File' }) }
    } else {
        Add-Target $fdRoot 'Dir'   # removes combonotes/moderncombonotes/notes too
    }
}

# images\  -> only NappuSakku's own PNGs, by exact name (folder kept, shared)
$glyphs = @('U','D','F','B','UF','UB','DF','DB','N',
            'QCF','QCB','DP','RDP','HCF','HCB','SPD','DD','FF','BB',
            '[B]F','[D]U','720','360F','360B')
$imgNames = @('fist','foot') + $glyphs
foreach ($n in $imgNames) {
    Add-Target (Join-Path $images ($n + '.png')) 'File'   # LiteralPath handles [ ]
}

# ----- Preview -----------------------------------------------------------
if ($targets.Count -eq 0) {
    Write-Host "Nothing to remove - NappuSakku does not appear to be installed here." -ForegroundColor Green
    exit 0
}

Write-Host "The following will be DELETED:" -ForegroundColor Yellow
foreach ($t in $targets) {
    $tag = if ($t.Kind -eq 'Dir') { '[dir ]' } else { '[file]' }
    Write-Host ("  {0} {1}" -f $tag, $t.Path.Substring($rf.Length + 1))
}
if ($KeepNotes) {
    Write-Host ""
    Write-Host "-KeepNotes: your combonotes/moderncombonotes/notes.json are PRESERVED." -ForegroundColor Green
} else {
    Write-Host ""
    Write-Host "NOTE: this also deletes your saved combo/character notes." -ForegroundColor Yellow
    Write-Host "      Re-run with -KeepNotes to keep them." -ForegroundColor Yellow
}
Write-Host ""
Write-Host "The autorun\, data\ and images\ folders themselves are KEPT." -ForegroundColor DarkGray
Write-Host ""

# ----- Confirm -----------------------------------------------------------
if (-not $Force) {
    $ans = Read-Host "Proceed? (y/N)"
    if ($ans -notmatch '^(y|yes)$') {
        Write-Host "Aborted. Nothing was changed." -ForegroundColor Cyan
        exit 0
    }
}

# ----- Delete ------------------------------------------------------------
$removed = 0; $failed = 0
foreach ($t in $targets) {
    try {
        if ($t.Kind -eq 'Dir') {
            Remove-Item -LiteralPath $t.Path -Recurse -Force
        } else {
            Remove-Item -LiteralPath $t.Path -Force
        }
        Write-Host ("  removed  {0}" -f $t.Path.Substring($rf.Length + 1)) -ForegroundColor Green
        $removed++
    } catch {
        Write-Host ("  FAILED   {0}  ({1})" -f $t.Path.Substring($rf.Length + 1), $_.Exception.Message) -ForegroundColor Red
        $failed++
    }
}

# If KeepNotes emptied a char folder / the framedata root, tidy up empties.
if ($KeepNotes -and (Test-Path -LiteralPath $fdRoot -PathType Container)) {
    Get-ChildItem -LiteralPath $fdRoot -Directory | ForEach-Object {
        if (-not (Get-ChildItem -LiteralPath $_.FullName -Force)) { Remove-Item -LiteralPath $_.FullName -Force }
    }
    if (-not (Get-ChildItem -LiteralPath $fdRoot -Force)) { Remove-Item -LiteralPath $fdRoot -Force }
}

Write-Host ""
Write-Host ("Done. Removed {0} item(s), {1} failure(s)." -f $removed, $failed) -ForegroundColor Cyan
if ($failed -gt 0) {
    Write-Host "Tip: close SF6 and REFramework first - a running game can lock these files." -ForegroundColor Yellow
}
